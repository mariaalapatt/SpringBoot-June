package com.example.demo.Products;

import com.example.demo.Products.Entity.Product;
import com.example.demo.Products.Service.ProductService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;


@SpringBootApplication

public class DemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoApplication.class, args);
		System.out.println("Started");
	}


	@Bean
	CommandLineRunner runner(ProductService productService) {
		return args -> {
			productService.save(new Product(1L, "SHOES", "BATA", 600D, "BLACK", 8L, 4L,"CHENNAI"));
			productService.save(new Product(2L, "SHIRT", "PUMA", 125D, "YELLOW", 7L, 5L,"BOMBAY"));
			productService.save(new Product(3L, "SHIRT", "PUMA", 250D, "WHITE", 4L, 5L,"COCHIN"));
			productService.save(new Product(4L, "NOTE", "NOTEBOOK", 15D, "RED", 7L, 5L,"CHENNAI"));
			productService.save(new Product(5L, "SALWAR", "MYNTRA", 125D, "YELLOW", 4L, 9L,"COCHIN"));
		};
	}
}
