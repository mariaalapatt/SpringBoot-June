package com.example.demo;


import com.example.demo.Products.Entity.Product;
import com.example.demo.Products.Repository.ProductRepository;
import com.example.demo.Products.Service.ProductService;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;


import java.util.ArrayList;
import java.util.List;

import static org.mockito.Mockito.when;

public class ProductControllerApiTest {


    @InjectMocks
    ProductService productService;

    @Mock
    ProductRepository productRepository;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
    }

  @Test
    public void findByBrand(){
        List<Product> list = new ArrayList<>();
        Product pd1 = new Product(1L, "SHOES", "BATA", 600D, "BLACK", 8L, 4L,"CHENNAI");
        Product pd2 = new Product(2L, "SHIRT", "PUMA", 125D, "YELLOW", 7L, 5L,"BOMBAY");
        list.add(pd1);
        list.add(pd2);
        when(productService.getByProductnameAndBrand("SHOES","BATA")).thenReturn(list);
        Assert.assertNotNull(list);

    }

}




