package com.example.demo.Products.Repository;

import com.example.demo.Products.Entity.Product;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ProductRepository extends CrudRepository<Product,Integer> {

    List<Product> findByBrand(String brand);

    Product findBySize(Long size);


    @Query(value = "SELECT * from Product where colour = ?1", nativeQuery = true)
    List<Product> findByColour(String colour);

    List<Product> findByProductnameAndBrand(String productname,String brand);
    List<Product> findByProductnameAndPrice(String productname,Double price);
    List<Product> findByProductnameAndColour(String productname,String colour);
    List<Product> findByProductnameAndSize(String productname,Long size);
    List<Product> findBySKU(String sku);
    List<Product> findByAvailablenumber(Long availablenumber);





}
