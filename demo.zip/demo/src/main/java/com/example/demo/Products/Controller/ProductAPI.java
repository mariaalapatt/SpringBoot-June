package com.example.demo.Products.Controller;

import com.example.demo.Products.Entity.Product;
import com.example.demo.Products.Service.ProductService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/v1/products")
public class ProductAPI {

    private ProductService productService;

    public ProductAPI(ProductService productService) {
        this.productService = productService;
    }

    @RequestMapping("/{brand}")
    public ResponseEntity<List<Product>> findByBrand(@PathVariable String brand) {
        Optional<List<Product>> stock = Optional.ofNullable(productService.getProductByBrand(brand));
            return ResponseEntity.ok(stock.get());

    }


    @RequestMapping("colour/{colour}")
    public ResponseEntity<List<Product>> findByColour(@PathVariable String colour) {
        Optional<List<Product>> stock = Optional.ofNullable(productService.getProductByColour(colour));
        return ResponseEntity.ok(stock.get());

    }


    @RequestMapping("productandbrand/{productname}/{brand}")
    public ResponseEntity<List<Product>> findByProductAndBrand(@PathVariable String productname,@PathVariable String brand) {
        Optional<List<Product>> stock = Optional.ofNullable(productService.getByProductnameAndBrand(productname,brand));
        return ResponseEntity.ok(stock.get());
    }

    @RequestMapping("productandprice/{productname}/{price}")
    public ResponseEntity<List<Product>> findByProductAndBrand(@PathVariable String productname,@PathVariable Double price) {
        Optional<List<Product>> stock = Optional.ofNullable(productService.getByProductnameAndPrice(productname,price));
        return ResponseEntity.ok(stock.get());
    }

    @RequestMapping("productandsize/{productname}/{size}")
    public ResponseEntity<List<Product>> findByProductAndBrand(@PathVariable String productname,@PathVariable Long size) {
        Optional<List<Product>> stock = Optional.ofNullable(productService.getByProductnameAndSize(productname,size));
        return ResponseEntity.ok(stock.get());
    }


    @RequestMapping("productBysku/{sku}")
    public ResponseEntity<List<Product>> findBySKU(@PathVariable String sku) {
        Optional<List<Product>> stock = Optional.ofNullable(productService.getBySKU(sku));
        return ResponseEntity.ok(stock.get());
    }

    @RequestMapping("productByAvailableNumer/{availablenumber}")
    public ResponseEntity<List<Product>> findByAvailableNumber(@PathVariable Long availablenumber) {
        Optional<List<Product>> stock= Optional.ofNullable(productService.getAvailableproduct(availablenumber));
        return ResponseEntity.ok(stock.get());
    }

    @RequestMapping("productandcolour/{productname}/{colour}")
    public ResponseEntity<List<Product>> findByProductAndColour(@PathVariable String productname,@PathVariable String colour) {
        Optional<List<Product>> stock = Optional.ofNullable(productService.getByProductnameAndColour(productname,colour));
        return ResponseEntity.ok(stock.get());

    }



}

