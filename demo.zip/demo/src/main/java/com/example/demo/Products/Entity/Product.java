package com.example.demo.Products.Entity;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name ="PRODUCT")
public class Product {
    @Id
    @GeneratedValue
    private Long id;

    private String productname;
    private String brand;
    private Double price;
    private String colour;
    private Long size;
    private Long availablenumber;
    private String SKU;

    public Product() {
    }

    public Product(Long id, String productname, String brand, Double price, String colour, Long size, Long availablenumber,String SKU) {
        this.id = id;
        this.productname =productname;
        this.brand = brand;
        this.price = price;
        this.colour = colour;
        this.size = size;
        this.availablenumber = availablenumber;
        this.SKU =SKU;
    }

    @Override
    public String toString() {
        return "Product{" +
                "id=" + id +
                ", productname='" + productname + '\'' +
                ", brand='" + brand + '\'' +
                ", price=" + price +
                ", colour='" + colour + '\'' +
                ", size=" + size +
                ", availablenumber=" + availablenumber +
                '}';
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getProductname() {
        return productname;
    }

    public void setProductname(String productname) {
        this.productname = productname;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public String getColour() {
        return colour;
    }

    public void setColour(String colour) {
        this.colour = colour;
    }

    public Long getSize() {
        return size;
    }

    public void setSize(Long size) {
        this.size = size;
    }

    public Long getAvailablenumber() {
        return availablenumber;
    }

    public void setAvailablenumber(Long availablenumber) {
        this.availablenumber = availablenumber;
    }

    public String getSKU() {
        return SKU;
    }

    public void setSKU(String SKU) {
        this.SKU = SKU;
    }
}
