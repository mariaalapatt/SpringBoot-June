package com.example.demo.Products.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;


@Controller
public class ProductController {


    public String list() {
        return "products";
    }
}
