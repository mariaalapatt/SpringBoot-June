package com.example.demo.Products.Service;


import com.example.demo.Products.Entity.Product;
import com.example.demo.Products.Repository.ProductRepository;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;

@Service
@Transactional
public class ProductService {

    private ProductRepository productRepository;

    public ProductService(ProductRepository productRepository) {
        this.productRepository = productRepository;
    }


    public List<Product> getProductByBrand(String brand){
        return productRepository.findByBrand(brand);
    }


    public List<Product> getProductByColour(String colour){
        return productRepository.findByColour(colour);
    }


    public List<Product> getByProductnameAndBrand(String productname,String brand){
        return productRepository.findByProductnameAndBrand(productname,brand);
    }

    public List<Product> getByProductnameAndPrice(String productname,Double price){
        return productRepository.findByProductnameAndPrice(productname,price);
    }

    public List<Product> getByProductnameAndSize(String productname,Long size){
        return productRepository.findByProductnameAndSize(productname,size);
    }

    public List<Product> getByProductnameAndColour(String productname,String colour){
        return productRepository.findByProductnameAndColour(productname,colour);
    }


    public List<Product> getBySKU(String sku){
        return productRepository.findBySKU(sku);
    }

    public List<Product> getAvailableproduct(Long available){
        return productRepository.findByAvailablenumber(available);
    }


    public Product getProductBySize(Long size){
        return productRepository.findBySize(size);
    }

    public Product save(Product product) {
        return productRepository.save(product);
    }
}
